#ifndef DATA_H
#define DATA_H

#include <stdbool.h>
#include <assert.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct student
{
	int age;
	int ID;
}STUDENT;

typedef struct class
{
	int count; //idk if this is necessary
	int length;
	STUDENT **array;
}CLASS;
CLASS* createDataSet(int maxNum);
void destroyDataSet(CLASS* c);
bool searchID(CLASS* c, int id);
void insertion(CLASS *c, int id, int age1);
void deletion(CLASS *c, int id);
void print(CLASS *test); 
#endif
