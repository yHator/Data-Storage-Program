/*
Yuka Hatori
finalProjects
app2
ALL SEARCHES BASED ON ID
YE
frequent searches
thats about it
*/
#include "app2.h"
/****
prototypes of the functions that are static in this class
****/
static void makeRoom(CLASS*, int);
/****
my method for allocating dummy students who will take on actual student values if one is inserted
otherwise, it will stay dummy node
this works because a student's age will never be 0, nor their id
****/
static void makeRoom(CLASS *c, int locat)
{
        assert(c!= NULL);
        STUDENT *sp;
        sp = malloc(sizeof(STUDENT));
        assert(sp != NULL);
        c->array[locat] = sp;
        sp->ID = 0;
	sp->age = 0;

}
/****

****/
CLASS* createDataSet(int maxNum)
{
	CLASS *new = malloc(sizeof(CLASS));
	new->count = 0;
	new->length = maxNum;
	new->array = malloc(sizeof(CLASS*)*maxNum);
	for (int i = 0; i < new->length; i++)
	{
		makeRoom(new, i);
	}
	return new;	
}
/****
 the data set
make sure all the students are destroy
then destroy array and class
****/
void destroyDataSet(CLASS* c)
{
	assert(c != NULL);
	for (int i = 0; i < c->length; i++)
	{
		free(c->array[i]);	
	}
	free (c->array);
	free(c);
}
/****
when I initialized the array, if there wasn't a student i just set the values to default 0s because the age and the id can never be 0 when you actually input info, so it is my check
****/
bool searchID(CLASS* c, int id)
{
	assert (c != NULL);
	bool found = false;
	if (c->array[id]->age == 0)
	{
		return found;	
	}
	found = true;
	return found;
}
void insertion(CLASS *c, int id, int age1)
{
	assert (c != NULL);
	STUDENT *new = malloc(sizeof(STUDENT));
	new->ID = id;
	new-> age= age1;
	c->array[id] = new;
}
/****
I "delete" the existence of that student, and leave a dummy student insidefor the next time that I have to insert 
****/
void deletion(CLASS *c, int id)
{
	assert (c != NULL);
	c->array[id]->age = 0;
	c->array[id]->ID = 0;
}
/****
a print function so I can see if my methods worked or not
****/
void print(CLASS *test)
{
	assert(test != NULL);
	for (int i = 0; i < test->length; i++)
	{
		if (test->array[i]->age != 0)
        	printf("age: %d, id: %d\n", test->array[i]->age, test->array[i]->ID);
	} 
}
