#include "app2.h"

int main()
{
        printf("Hello.\n");
        srand(time(NULL));
        CLASS *test;
        //the max value of students should be 3000, according to lab instruction
        //test = createDataSet(3000);//
        test = createDataSet(3000);
        int numOfStud = 0;
        int subsequentID = 0;
        int firstID = (rand() % 2) + 1;
	
        while (numOfStud < 3000)
        //while(numOfStud< 1000) 
        {
                //int firstID = (rand() % 2) + 1;
                int randAge = (rand() % 13) + 18;
                //you need to make the secID
                subsequentID += firstID;
                insertion(test, subsequentID, randAge);
                numOfStud++;
        }
	
	//insertion(test, 1, 18);
	//insertion(test, 2, 18);
	print(test);
	int rID = (rand() % 2000) + 1;
	bool found = searchID(test, rID);
	printf("ID %d is found (%d)", rID, found);//will return 0 if not found, 1 if found
        //int deID = 2;
        //int deID = (rand() % 2000) + 1;
        deletion(test, rID);
	printf("After delete.\n");
        print(test);
	printf("Hello, I have provided code if you would like to see it work on a smaller scale. Thank you!\n");
        destroyDataSet(test);

        return 0;
}

