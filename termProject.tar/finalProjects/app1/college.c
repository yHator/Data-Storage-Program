#include "app1.h"
//#include <stdlib.h>
//#include <time.h>
/****
fill your whatever with 3000 students ranging from age 18 - 30
but actually only fill to 1,000, and the 3,000 is max size
HOW TO GENERATE RANDOM IDS:
implement a random generator, 1 or 2
first ID can be determined as return val of random int generator (1 or 2)
for each remaining, id is determined by prev id plus return of random int generatl
ok then put in ur thingy
search based on ID
generate a student id and delete if found
*****/
int main()
{
        printf("Hello!\n");
        srand(time(NULL));
        CLASS *test;
        //the max value of students should be 3000, according to lab instruction
        test = createDataSet(3000, 18, 13, 30);
       
	//test = createDataSet(5, 18, 13, 30);
        
	int numOfStud = 0;
        int subsequentID = 0;
        int firstID = (rand() % 2) + 1;
	int runt = 13;
        while (numOfStud < runt)
        while(numOfStud< 1000) 
        {
                int firstID = (rand() % 2) + 1;
                int randAge = (rand() % 13) + 18;
                //you need to make the secID
                subsequentID += firstID;
                insertion(test, subsequentID, randAge);
                numOfStud++;
       } 

	int gap = maxAgeGap(test);
	printf("Gap: %d\n", gap);	
	print(test);

	/*	
	insertion(test, 1, 18);
	insertion(test, 2, 19);
	insertion(test, 3, 20);
	insertion(test, 4, 21);
	insertion(test, 5, 22);
	print(test);
	printf("\n\n");
	int run = 13;
        
	//int gap = maxAgeGap(test);
        //printf("Gap: %d\n", gap);       
	*/
		
	
        int deAge = (rand() % 13) + 18;
        printf("before delete.\n");
	deletion(test, deAge);
        printf("after delete.\n");
	print(test);
	gap = maxAgeGap(test);
        printf("Gap: %d\n", gap);  
        destroyDataSet(test);
	printf("If you want to see my code work on a smaller scale, I have included code for that too. Thank you!\n");
	printf("Bye bye.\n");
	return 0;
}
