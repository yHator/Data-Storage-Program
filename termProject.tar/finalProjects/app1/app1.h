#ifndef DATA_H
#define DATA_H

#include <stdbool.h>
#include <assert.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*typedef struct node NODE;
typedef struct list LIST;
typedef struct class CLASS;
*/
typedef struct node
{
        int ID;
        struct node *next;
        struct node*prev;
}NODE;
//the list keeps track of linked list
typedef struct list
{
        int count;
        //int maxAge;
        //int minAge;
        NODE *head;
}LIST;
typedef struct class
{
        int countTot; //honestly unecessary i think
        int length; //the max number that teacher said should be allowed
        int maxAge;
        int minAge;
        LIST **array; //array based on age, full of linked lists of IDs
}CLASS;

CLASS* createDataSet(int maxNum, int min, int differenceInAgeRange, int maxAge1);
void destroyDataSet(CLASS* c);
LIST *searchAge(CLASS *c, int findAge, bool found);
void insertion(CLASS* c, int id, int age);
void deletion(CLASS* c, int age);
int maxAgeGap(CLASS *c);//works
void print(CLASS *test);
#endif

