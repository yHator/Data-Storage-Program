/*
Yuka Hatori
App 3
implementation of code
*/
#include "app1.h"
/*
doubly linked array of nodes with a dummy node inside an array that is tracked by struct class
*/
/*
typedef struct node
{
        int ID;
        NODE *next;
        NODE *prev;
}NODE;
//the list keeps track of linked list
typedef struct list
{
        int count;
        //int maxAge;
        //int minAge;
        NODE *head;
}LIST;
typedef struct class
{
        int countTot; //honestly unecessary i think
        int length; //the max number that teacher said should be allowed
        int maxAge;
        int minAge;
        LIST **array; //array based on age, full of linked lists of IDs
}CLASS;
*/
int minAgePassedIn; //THIS KEEPS TRACK OF AGE 18
int maxAgePassedIn;
int range;
/****
returns the index of where that age should be
ages are stored in descending order (highest to lowest)
****/
static int locatAge(CLASS *c, int findAge)
{
        assert ( c!= NULL);
        //age range is 30 - 18 = 13 ages, so array index 0-12
        int locat = 0;
        locat = findAge - minAgePassedIn;
        return locat;


}
/**** 
makes the dummy node for each list in the class
****/
static void makeDummy(LIST *c)
{
        assert (c != NULL);
        c->head = malloc(sizeof(NODE));
        assert(c->head != NULL);
        c->head->next = c->head;
        c->head->prev = c->head;
	c->head->ID = 5678;
}
/****
makes the list in each slot of the array of class
****/
static void makeList(CLASS *c, int locat)
{
        assert(c!= NULL);
        LIST *sp;
        sp = malloc(sizeof(LIST));
        assert(sp != NULL);
        c->array[locat] = sp;
        sp->count = 0;
        sp->head = NULL;
}
/****
creates the data set, which is the class
it initializes the class object, and then the array of
****/
CLASS* createDataSet(int maxNum, int min, int differenceInAgeRange, int maxAge1)//pass in age 18
{
        minAgePassedIn = min;
        maxAgePassedIn = maxAge1;
        range = differenceInAgeRange;
        CLASS *new;
        new = malloc(sizeof(CLASS));
        assert (new != NULL);
        new->array = malloc(sizeof(NODE*)*differenceInAgeRange); //12 is the number of ages
        assert(new->array != NULL);
        new->length = maxNum;
        //printf("before loop.\n");
        for (int i = 0; i < differenceInAgeRange; i++)//basically, i'm trying to initialize the  dummy nodes
        {
                makeList(new, i);
                makeDummy(new->array[i]);
        }
        //printf("after for loop.\n");
        new->countTot = 0;//there are no actual student info saved in my class yet
        new->maxAge = 0;
        new->minAge = -1;
        return new;
}
/****
destroys the linked list associated to the age
****/
static void destroyList(LIST *pList)
{
        assert(pList != NULL);
        NODE *pTail =pList->head->prev;
        //      printf("p->tail %d," 
        NODE *pDel = pList->head->next;
        while(pList->head != pTail)
        {
                pDel = pList->head;
                pList->head = pDel->next;
                free(pDel);
        }
        pList->head->next = pList->head;
	pList->head->prev = pList->head;
        //      free(pTail);//don't do this because you get a seg fault

}
/****
destroy the data set
****/
void destroyDataSet(CLASS* c)//this is wrong. mebbe
{
	assert (c != NULL);
	for (int i = 0; i<range; i++)
	{
		if (c->array[i] != NULL)
		{
			destroyList(c->array[i]);
		}
	}
	free (c);
}
/****
return the linked list associated with the searched for age
****/
LIST * searchAge(CLASS *c, int findAge, bool found)
{
        assert (c != NULL);
        found = false;
        int locat = locatAge(c, findAge);
        //in order to check if the age is there, because there should be a dummy node in each array slot, just check if there is something in there other than the dummy node
        //if (c->age[location]->next != c->age[location])
        if (c->array[locat]->count > 0)
        {
                found = true;
                return c->array[locat];
        }
        return NULL;
}
/****
insert a new student (with id and age)
make sure that you update the minAge and maxAge because it might change with every inserted value
increase count on class and list
****/
void insertion(CLASS* c, int id, int age)
{
        assert (c !=NULL);
        int locat = locatAge(c, age);
        NODE * new = malloc(sizeof(NODE));
        assert (new != NULL);
        if (c->countTot < c->length)
        {
                if (c->minAge == -1)
                {
                        c->minAge = age;
                }
                if (c->maxAge < age)
                {
                        c->maxAge = age;
                }
                if (c->minAge > age)
                {
                        c->minAge = age;
                        //printf("c->minAge = %d\n", c->minAge);
                }
                new->ID = id;
                c->countTot++;
                //printf("c->counttot %d\n", c->countTot);
                c->array[locat]->count++;
                //printf("c count: %d\n",  c->array[locat]->count);
                new->next = c->array[locat]->head->next;//ehehehe code copied from project4
                new->prev = c->array[locat]->head;
                c->array[locat]->head->next->prev = new;
                c->array[locat]->head->next = new;
        }
}
/****
you must delete the entire link list associated to the age
the reallocate the dummy
also make sure to update the min max age after you deleted the ids associated to an age
****/
void deletion(CLASS* c, int age)//min and max need to be updated
{
        assert (c!= NULL);
        int locat = locatAge(c,age);
        c->countTot -= c->array[locat]->count;
        //printf("here.\n");
        if (c->array[locat]->count == 0)
        {
                return;
        }
        destroyList(c->array[locat]);
	//makeDummy(c->array[locat]);
        //printf("NO.\n");
        c->array[locat]->count = 0;
        for (int i =0; i <range; i++)//12 is the array length pls fix later
        {
                int ageOf =locatAge(c, i+minAgePassedIn) + minAgePassedIn;//the age at that index
                if (c->array[i]->count > 0 && (ageOf > c->maxAge))
                {
                        c->maxAge = ageOf;
                }
                if (c->array[i]->count > 0 && (ageOf < c->minAge))
                {
                        c->minAge = ageOf;
                }
        }

}
/****
calculates the max age gap based on the ages it stored in the class
****/
int maxAgeGap(CLASS *c)
{
        assert (c != NULL);
        //printf("Hello.\n");
        printf("maxAge: %d, minAge: %d\n",c->maxAge, c->minAge);
        if (c->minAge == -1)
        {
                printf("There is only one value.\n");
                return c->maxAge;
        }
        int gap = c->maxAge - (c->minAge);
        return gap;
}
/****
print out all the ids associated to each age
****/
void print(CLASS *test)
{
        int run = 13;
        for (int i = 0; i < run; i++)
        {
                //NODE *temp = test->array[i]->head->next;
                printf("Array location:%d Age:%d\n", i, (18+i));
                NODE *temp = test->array[i]->head->prev;
		while (temp != test->array[i]->head)
                {
                        printf("Id: %d\n", temp->ID);
                        //temp = test->array[i]->head->next;
                	temp = temp->prev;
		}
        }
}
